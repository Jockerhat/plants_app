class CategoryModel {
  final String title;
  final bool isSelected;

  CategoryModel(
    this.title, {
    required this.isSelected,
  });
}

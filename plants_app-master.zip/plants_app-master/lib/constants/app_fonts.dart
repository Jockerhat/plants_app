import 'package:plants_app/constants/app_imports.dart';

class AppFonts {
  static TextStyle font20Black = TextStyle(
    fontSize: 20.sp,
    color: AppColors.blackColor,
  );
}
